#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

# --- Read README for long description ---
def read(fname):
    with open(fname, 'r', encoding='utf-8') as f:
        return f.read()

setup(
    name="laniakea-protocol",
    version="1.0.0",
    description="A cosmic computational organism for universal problem-solving and consciousness expansion.",
    long_description=read('README.md'),
    long_description_content_type="text/markdown",
    author="QalamHipHop",
    author_email="qalamhiphop@github.com",
    url="https://github.com/QalamHipHop/laniakea-protocol",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "pydantic>=2.4.0,<3.0.0",
        "fastapi>=0.110.0,<1.0.0",
        "uvicorn[standard]>=0.27.1,<1.0.0",
        "websockets>=12.0,<13.0",
        "aiohttp>=3.9.3,<4.0.0",
        "cryptography>=42.0.5,<43.0.0",
        "aiosqlite>=0.19.0,<1.0.0",
        "psycopg2-binary>=2.9.9,<3.0.0",
        "python-dotenv>=1.0.1,<2.0.0",
        "numpy>=1.24.0,<2.0.0",
        "scipy>=1.11.0,<2.0.0",
        "requests>=2.31.0,<3.0.0",
        "openai>=1.30.0,<2.0.0",
        "networkx>=3.1,<4.0",
    ],
    extras_require={
        "viz": [
            "matplotlib>=3.7.0,<4.0.0",
            "plotly>=5.18.0,<6.0.0",
        ],
        "ml": [
            "scikit-learn>=1.3.0,<2.0.0",
        ],
        "cache": [
            "redis>=5.0.0,<6.0.0",
        ],
        "dev": [
            "pytest>=7.4.0,<8.0.0",
            "pytest-asyncio>=0.21.0,<1.0.0",
            "black>=23.0.0,<24.0.0",
            "flake8>=6.0.0,<7.0.0",
            "mypy>=1.5.0,<2.0.0",
        ],
        "docs": [
            "mkdocs>=1.5.0,<2.0.0",
            "mkdocs-material>=9.4.0,<10.0.0",
        ],
    },
    python_requires=">=3.11",
    entry_points={
        "console_scripts": [
            "laniakea=main:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
