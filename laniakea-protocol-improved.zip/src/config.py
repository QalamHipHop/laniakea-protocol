'''
Laniakea Protocol - Configuration Management

This module handles the loading and validation of all environment variables
and configuration settings for the Laniakea Protocol node.
'''
import os
from typing import List
from dotenv import load_dotenv
import logging

# --- Setup Logger ---
logger = logging.getLogger(__name__)

# --- Load .env file ---
load_dotenv()

# --- Helper function for boolean conversion ---
def get_bool_env(var_name: str, default: bool = False) -> bool:
    '''Converts environment variable to boolean, handling various string representations.'''
    value = os.getenv(var_name, str(default)).lower()
    return value in ['true', '1', 't', 'y', 'yes']

# ===========================================
# Node Configuration
# ===========================================
HOST = os.getenv("NODE_HOST", "0.0.0.0")
P2P_PORT = int(os.getenv("NODE_P2P_PORT", "5000"))
API_PORT = int(os.getenv("NODE_API_PORT", "8000"))
NODE_NAME = os.getenv("NODE_NAME", "laniakea-node-1")

# ===========================================
# Security
# ===========================================
ALLOWED_ORIGINS_STR = os.getenv("ALLOWED_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000")
ALLOWED_ORIGINS = [origin.strip() for origin in ALLOWED_ORIGINS_STR.split(',')]

SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    logger.critical("SECRET_KEY is not set! This is required for security features. Exiting.")
    raise ValueError("SECRET_KEY must be set in the environment for production.")

# ===========================================
# AI Services (Cognitive Core)
# ===========================================
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4-turbo-preview")
if not OPENAI_API_KEY:
    logger.warning("OPENAI_API_KEY is not set. Cognitive Core will be disabled.")

# ===========================================
# External APIs (Oracles)
# ===========================================
NASA_API_KEY = os.getenv("NASA_API_KEY")
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")
ALPHAVANTAGE_API_KEY = os.getenv("ALPHAVANTAGE_API_KEY")
WOLFRAM_APP_ID = os.getenv("WOLFRAM_APP_ID")

# ===========================================
# Database
# ===========================================
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./data/laniakea.db")

# ===========================================
# Redis (Optional Caching)
# ===========================================
REDIS_URL = os.getenv("REDIS_URL") # e.g., "redis://localhost:6379/0"

# ===========================================
# Logging
# ===========================================
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_FILE = os.getenv("LOG_FILE", "logs/laniakea.log")

# ===========================================
# Performance
# ===========================================
MAX_WORKERS = int(os.getenv("MAX_WORKERS", "4"))
CONNECTION_POOL_SIZE = int(os.getenv("CONNECTION_POOL_SIZE", "10"))
REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "30"))

# ===========================================
# Blockchain Parameters
# ===========================================
BLOCK_TIME = int(os.getenv("BLOCK_TIME", "60")) # in seconds
DIFFICULTY_ADJUSTMENT_INTERVAL = int(os.getenv("DIFFICULTY_ADJUSTMENT_INTERVAL", "10")) # in blocks

# ===========================================
# Feature Flags
# ===========================================
ENABLE_SIMULATION = get_bool_env("ENABLE_SIMULATION", False)
ENABLE_SELF_EVOLUTION = get_bool_env("ENABLE_SELF_EVOLUTION", True)
ENABLE_COGNITIVE_CORE = get_bool_env("ENABLE_COGNITIVE_CORE", True) and bool(OPENAI_API_KEY)
ENABLE_REDIS_CACHE = get_bool_env("ENABLE_REDIS_CACHE", False) and bool(REDIS_URL)

# ===========================================
# Network Bootstrap & Authorities
# ===========================================
BOOTSTRAP_NODES_STR = os.getenv("BOOTSTRAP_NODES", "bootstrap1.laniakea.network:5000,bootstrap2.laniakea.network:5000")
BOOTSTRAP_NODES = []
for node in BOOTSTRAP_NODES_STR.split(','):
    if ':' in node:
        host, port = node.split(':')
        BOOTSTRAP_NODES.append((host, int(port)))

AUTHORITY_NODES_STR = os.getenv("AUTHORITY_NODES", "authority1.laniakea.network,authority2.laniakea.network")
AUTHORITY_NODES = {node.strip() for node in AUTHORITY_NODES_STR.split(',')}

def get_bootstrap_nodes() -> List[tuple]:
    '''Returns the list of bootstrap nodes.'''
    return BOOTSTRAP_NODES

def is_authority(node_id: str) -> bool:
    '''Checks if a given node ID is an authority.'''
    return node_id in AUTHORITY_NODES

# --- Log initial configuration for debugging ---
logger.info("Laniakea Protocol configuration loaded.")
logger.info(f"Log Level: {LOG_LEVEL}")
logger.info(f"Cognitive Core Enabled: {ENABLE_COGNITIVE_CORE}")
logger.info(f"Self-Evolution Enabled: {ENABLE_SELF_EVOLUTION}")
logger.info(f"Database URL: {DATABASE_URL}")
