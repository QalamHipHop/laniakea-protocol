# 🚀 Laniakea Protocol - راهنمای استقرار

این راهنما شما را در فرآیند استقرار پروتوکل Laniakea در محیط‌های مختلف، از توسعه محلی تا سرورهای production، یاری می‌کند.

## 📋 پیش‌نیازها

قبل از شروع، اطمینان حاصل کنید که ابزارهای زیر روی سیستم شما نصب شده‌اند:

- **Git:** برای دریافت کد پروژه.
- **Docker:** برای ساخت و اجرای کانتینرها.
- **Docker Compose:** برای ارکستراسیون سرویس‌ها.
- **یک ویرایشگر متن:** مانند VS Code, Nano, یا Vim برای ویرایش فایل `.env`.

---

## 📦 استقرار محلی (برای توسعه)

این روش ساده‌ترین راه برای راه‌اندازی پروژه روی سیستم شخصی شماست.

### ۱. دریافت پروژه

```bash
git clone https://github.com/QalamHipHop/laniakea-protocol.git
cd laniakea-protocol
```

### ۲. تنظیم متغیرهای محیطی

فایل `.env.example` را به `.env` کپی کرده و مقادیر آن را ویرایش کنید.

```bash
cp .env.example .env
nano .env  # یا از ویرایشگر مورد علاقه خود استفاده کنید
```

**مهم:** حتماً یک `SECRET_KEY` قوی و کلید `OPENAI_API_KEY` خود را وارد کنید.

### ۳. راه‌اندازی با Docker Compose

این دستور تمام سرویس‌های مورد نیاز (نود Laniakea، دیتابیس PostgreSQL و Redis) را به صورت خودکار راه‌اندازی می‌کند.

```bash
docker-compose up --build -d
```

- `--build`: ایمیج داکر را قبل از راه‌اندازی می‌سازد.
- `-d`: سرویس‌ها را در پس‌زمینه (detached mode) اجرا می‌کند.

### ۴. بررسی وضعیت

برای مشاهده لاگ‌ها و وضعیت سرویس‌ها:

```bash
docker-compose logs -f
```

برای توقف سرویس‌ها:

```bash
docker-compose down
```

**تبریک!** نود Laniakea شما اکنون روی آدرس `http://localhost:8000` در دسترس است.

---

## ☁️ استقرار روی سرور (Production)

این راهنما برای استقرار پروژه روی یک سرور مجازی (VPS) مانند DigitalOcean, Linode, یا Vultr طراحی شده است.

### ۱. آماده‌سازی سرور

ابتدا با SSH به سرور خود متصل شوید:

```bash
ssh root@YOUR_SERVER_IP
```

سپس Docker و Docker Compose را نصب کنید:

```bash
# نصب Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# نصب Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

### ۲. دریافت و تنظیم پروژه

مانند استقرار محلی، پروژه را clone کرده و فایل `.env` را تنظیم کنید.

```bash
git clone https://github.com/QalamHipHop/laniakea-protocol.git
cd laniakea-protocol
cp .env.example .env
nano .env
```

**نکته امنیتی:** در محیط production، مقادیر زیر را حتماً تغییر دهید:
- `SECRET_KEY`
- `POSTGRES_USER`
- `POSTGRES_PASSWORD`
- `ALLOWED_ORIGINS` (به دامنه سایت خود تغییر دهید)

### ۳. راه‌اندازی سرویس‌ها

با Docker Compose سرویس‌ها را در پس‌زمینه اجرا کنید:

```bash
docker-compose up --build -d
```

### ۴. تنظیم وب‌سرور معکوس (Reverse Proxy) با Nginx

برای امنیت بیشتر و فعال‌سازی SSL، توصیه می‌شود از Nginx به عنوان reverse proxy استفاده کنید.

```bash
# نصب Nginx
sudo apt update
sudo apt install nginx

# ایجاد فایل کانفیگ جدید
sudo nano /etc/nginx/sites-available/laniakea
```

محتوای زیر را در فایل کانفیگ قرار دهید (دامنه خود را جایگزین کنید):

```nginx
server {
    listen 80;
    server_name your_domain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

لینک سیمبولیک ایجاد کرده و Nginx را ری‌استارت کنید:

```bash
sudo ln -s /etc/nginx/sites-available/laniakea /etc/nginx/sites-enabled/
sudo systemctl restart nginx
```

### ۵. فعال‌سازی SSL با Let's Encrypt

برای امنیت ارتباطات، گواهی SSL رایگان از Let's Encrypt دریافت کنید.

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your_domain.com
```

Certbot به صورت خودکار کانفیگ Nginx شما را برای استفاده از HTTPS به‌روزرسانی می‌کند.

---

## ⚙️ مدیریت و نگهداری

### به‌روزرسانی پروژه

برای دریافت آخرین تغییرات و آپدیت پروژه:

```bash
# دریافت آخرین کد
git pull origin main

# بازسازی و ری‌استارت سرویس‌ها
docker-compose up --build -d
```

### پشتیبان‌گیری از دیتابیس

برای پشتیبان‌گیری از دیتابیس PostgreSQL:

```bash
docker-compose exec -T postgres pg_dumpall -c -U laniakea > dump_`date +%d-%m-%Y"_"%H_%M_%S`.sql
```

### بازیابی دیتابیس

برای بازیابی از یک فایل پشتیبان:

```bash
cat your_dump.sql | docker-compose exec -T postgres psql -U laniakea
```

---

موفق باشید! اگر با مشکلی مواجه شدید، لطفاً یک Issue در مخزن GitHub پروژه ایجاد کنید.
