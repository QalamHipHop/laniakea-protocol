# ⚡ Laniakea Protocol - راهنمای سریع شروع

این راهنما شما را در کمترین زمان ممکن برای راه‌اندازی نود Laniakea آماده می‌کند.

---

## 🎯 روش ۱: استفاده از Docker (پیشنهادی)

این ساده‌ترین و سریع‌ترین روش است.

### گام ۱: Clone کردن پروژه

```bash
git clone https://github.com/QalamHipHop/laniakea-protocol.git
cd laniakea-protocol
```

### گام ۲: تنظیم متغیرهای محیطی

```bash
cp .env.example .env
# ویرایش .env و اضافه کردن کلیدهای API
nano .env
```

### گام ۳: راه‌اندازی

```bash
docker-compose up -d
```

### گام ۴: دسترسی به داشبورد

باز کردن مرورگر و رفتن به:
```
http://localhost:8000/ui
```

**تمام!** نود شما اکنون فعال است.

---

## 🐍 روش ۲: نصب مستقیم با Python

اگر می‌خواهید بدون Docker کار کنید:

### گام ۱: Clone و ورود به پروژه

```bash
git clone https://github.com/QalamHipHop/laniakea-protocol.git
cd laniakea-protocol
```

### گام ۲: اجرای اسکریپت نصب

```bash
chmod +x install.sh
./install.sh
```

این اسکریپت به صورت خودکار:
- محیط مجازی Python ایجاد می‌کند
- تمام وابستگی‌ها را نصب می‌کند
- فایل `.env` را آماده می‌کند

### گام ۳: ویرایش فایل .env

```bash
nano .env
# کلیدهای API خود را اضافه کنید
```

### گام ۴: راه‌اندازی نود

```bash
chmod +x start_node.sh
./start_node.sh
```

### گام ۵: دسترسی به داشبورد

```
http://localhost:8000/ui
```

---

## 🔑 کلیدهای API مورد نیاز

برای فعال‌سازی کامل ویژگی‌ها، نیاز به کلیدهای زیر دارید:

| سرویس | کلید | ضروری؟ | لینک دریافت |
|--------|------|---------|-------------|
| OpenAI | `OPENAI_API_KEY` | ✅ بله | https://platform.openai.com/api-keys |
| NASA | `NASA_API_KEY` | ❌ خیر | https://api.nasa.gov/ |
| OpenWeather | `OPENWEATHER_API_KEY` | ❌ خیر | https://openweathermap.org/api |
| AlphaVantage | `ALPHAVANTAGE_API_KEY` | ❌ خیر | https://www.alphavantage.co/support/#api-key |
| Wolfram | `WOLFRAM_APP_ID` | ❌ خیر | https://products.wolframalpha.com/api/ |

**نکته:** کلید OpenAI برای فعال‌سازی Cognitive Core و Self-Evolution ضروری است.

---

## 📊 بررسی وضعیت

### بررسی لاگ‌ها

**با Docker:**
```bash
docker-compose logs -f laniakea-node
```

**بدون Docker:**
```bash
tail -f logs/laniakea.log
```

### بررسی API

```bash
curl http://localhost:8000/health
```

پاسخ موفق:
```json
{
  "status": "healthy",
  "version": "1.0.0"
}
```

---

## 🛑 توقف نود

**با Docker:**
```bash
docker-compose down
```

**بدون Docker:**
```bash
# فشار دادن Ctrl+C در ترمینال اجرا
```

---

## 🆘 عیب‌یابی

### مشکل: پورت در حال استفاده است

```bash
# تغییر پورت‌ها در .env
NODE_P2P_PORT=5001
NODE_API_PORT=8001
```

### مشکل: خطای اتصال به دیتابیس

```bash
# بررسی وضعیت PostgreSQL
docker-compose ps postgres

# ری‌استارت دیتابیس
docker-compose restart postgres
```

### مشکل: Cognitive Core فعال نیست

بررسی کنید که `OPENAI_API_KEY` در `.env` تنظیم شده باشد.

---

برای راهنمای کامل استقرار در production، فایل `DEPLOYMENT.md` را مطالعه کنید.
