# 🌌 Laniakea Protocol - فایل‌های بهبود یافته

این پوشه شامل تمام فایل‌های بهبود یافته و جدید برای پروژه Laniakea Protocol است.

---

## 📂 ساختار فایل‌ها

```
laniakea-protocol-improved/
├── setup.py                    # فایل نصب پکیج Python
├── install.sh                  # اسکریپت نصب خودکار
├── .env.example                # نمونه متغیرهای محیطی
├── Dockerfile                  # ایمیج Docker بهینه شده
├── docker-compose.yml          # ارکستراسیون سرویس‌ها
├── DEPLOYMENT.md               # راهنمای استقرار
├── QUICKSTART.md               # راهنمای سریع شروع
├── IMPROVEMENTS_SUMMARY.md     # خلاصه تمام بهبودها
├── README_IMPROVEMENTS.md      # این فایل
└── src/
    └── config.py               # مدیریت تنظیمات
```

---

## 🚀 نحوه استفاده

### روش ۱: جایگزینی کامل

```bash
# ۱. پشتیبان‌گیری از پروژه فعلی
cd /path/to/laniakea-protocol
cp -r . ../laniakea-protocol-backup

# ۲. کپی فایل‌های جدید
cp -r /home/ubuntu/laniakea-protocol-improved/* .

# ۳. ادامه با نصب
./install.sh
```

### روش ۲: کپی انتخابی

فقط فایل‌های مورد نیاز را کپی کنید:

```bash
# فایل‌های ضروری
cp laniakea-protocol-improved/setup.py .
cp laniakea-protocol-improved/install.sh .
cp laniakea-protocol-improved/.env.example .
cp laniakea-protocol-improved/src/config.py src/

# فایل‌های Docker
cp laniakea-protocol-improved/Dockerfile .
cp laniakea-protocol-improved/docker-compose.yml .

# مستندات
cp laniakea-protocol-improved/DEPLOYMENT.md .
cp laniakea-protocol-improved/QUICKSTART.md .
```

---

## 📋 فایل‌های کلیدی

### ۱. setup.py
**هدف:** نصب پروژه به عنوان یک پکیج Python

**ویژگی‌ها:**
- مدیریت وابستگی‌ها
- نصب optional dependencies
- Entry points برای CLI

**استفاده:**
```bash
pip install -e ".[dev,viz,ml,cache,docs]"
```

### ۲. install.sh
**هدف:** نصب خودکار پروژه

**ویژگی‌ها:**
- بررسی نسخه Python
- ایجاد محیط مجازی
- نصب وابستگی‌ها
- آماده‌سازی .env

**استفاده:**
```bash
chmod +x install.sh
./install.sh
```

### ۳. .env.example
**هدف:** نمونه تنظیمات محیطی

**شامل:**
- تنظیمات نود
- کلیدهای API
- تنظیمات دیتابیس
- Feature flags

**استفاده:**
```bash
cp .env.example .env
nano .env  # ویرایش مقادیر
```

### ۴. src/config.py
**هدف:** مدیریت متمرکز تنظیمات

**ویژگی‌ها:**
- بارگذاری .env
- اعتبارسنجی مقادیر
- مقادیر پیش‌فرض
- Logging

**استفاده:**
```python
from src.config import HOST, P2P_PORT, OPENAI_API_KEY
```

### ۵. Dockerfile
**هدف:** ساخت ایمیج Docker

**ویژگی‌ها:**
- Multi-stage build
- کاربر غیر root
- Health check
- حجم کم

**استفاده:**
```bash
docker build -t laniakea-protocol .
```

### ۶. docker-compose.yml
**هدف:** ارکستراسیون سرویس‌ها

**سرویس‌ها:**
- laniakea-node
- postgres
- redis

**استفاده:**
```bash
docker-compose up -d
```

---

## 🔧 تغییرات مهم

### ۱. مدیریت کلیدهای API

**قبل:**
```python
OPENAI_API_KEY = "sk-xxx"  # در کد
```

**بعد:**
```python
# در .env
OPENAI_API_KEY=sk-xxx

# در کد
from src.config import OPENAI_API_KEY
```

### ۲. CORS

**قبل:**
```python
allow_origins=["*"]
```

**بعد:**
```python
from src.config import ALLOWED_ORIGINS
allow_origins=ALLOWED_ORIGINS
```

### ۳. وابستگی‌ها

**قبل:**
```txt
openai>=1.0.0
```

**بعد:**
```txt
openai>=1.30.0,<2.0.0
```

---

## ✅ چک‌لیست نصب

- [ ] کپی فایل‌های جدید
- [ ] اجرای `install.sh`
- [ ] تنظیم `.env`
- [ ] تست با `docker-compose up -d`
- [ ] بررسی `http://localhost:8000/ui`
- [ ] مطالعه `DEPLOYMENT.md`

---

## 📚 مستندات

برای اطلاعات بیشتر:

- **QUICKSTART.md:** شروع سریع
- **DEPLOYMENT.md:** استقرار کامل
- **IMPROVEMENTS_SUMMARY.md:** خلاصه تغییرات
- **ARCHITECTURE.md:** معماری سیستم (در پروژه اصلی)

---

## 🆘 عیب‌یابی

### مشکل: فایل‌ها کپی نمی‌شوند

```bash
# بررسی مجوزها
ls -la laniakea-protocol-improved/

# اضافه کردن مجوز اجرا
chmod +x laniakea-protocol-improved/install.sh
```

### مشکل: import error

```bash
# نصب مجدد پکیج
pip install -e .
```

### مشکل: Docker build fails

```bash
# پاک کردن کش
docker system prune -a

# build مجدد
docker-compose build --no-cache
```

---

## 📞 پشتیبانی

اگر سوالی دارید:
1. مستندات را بررسی کنید
2. لاگ‌ها را چک کنید
3. Issue در GitHub ایجاد کنید

---

**موفق باشید! 🚀**

**توسعه‌دهنده:** Manus AI  
**تاریخ:** 4 نوامبر 2025
