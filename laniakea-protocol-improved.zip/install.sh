#!/bin/bash
# install.sh - Installation script for Laniakea Protocol

set -e  # Exit immediately if a command exits with a non-zero status.

# --- Banner ---
echo "==============================================="
echo "🌌 Installing Laniakea Protocol..."
echo "==============================================="

# --- Check for Python 3.11+ ---
echo "1. Checking Python version..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Error: Python 3 is not installed. Please install Python 3.11 or higher."
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
REQUIRED_VERSION="3.11"

if [ "$(printf '%s\n' "$REQUIRED_VERSION" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_VERSION" ]; then
    echo "❌ Error: Python $REQUIRED_VERSION+ is required, but version $PYTHON_VERSION was found."
    exit 1
fi

echo "✅ Python version $PYTHON_VERSION is compatible."

# --- Create and activate virtual environment ---
echo "\n2. Setting up virtual environment..."
if [ ! -d "venv" ]; then
    echo "   - Creating virtual environment in './venv'..."
    python3 -m venv venv
else
    echo "   - Virtual environment already exists."
fi

echo "   - Activating virtual environment..."
source venv/bin/activate

# --- Upgrade pip ---
echo "\n3. Upgrading pip..."
pip install --upgrade pip

# --- Install dependencies ---
echo "\n4. Installing project dependencies..."
# Install the project in editable mode with all optional dependencies
pip install -e ".[dev,viz,ml,cache,docs]"

# --- Setup .env file ---
echo "\n5. Setting up environment file..."
if [ ! -f ".env" ]; then
    echo "   - Creating .env file from .env.example..."
    cp .env.example .env
    echo "⚠️  Action required: Please edit the .env file and add your API keys and configurations."
else
    echo "   - .env file already exists. Skipping creation."
fi

# --- Create necessary directories ---
echo "\n6. Creating required directories..."
mkdir -p data logs
echo "   - Created './data' and './logs' directories."

# --- Final message ---
echo "\n==============================================="
echo "✅ Laniakea Protocol installation complete!"
echo "==============================================="
echo "\nNext steps:"
echo "1. Edit the .env file with your custom configurations and API keys."
echo "2. Make the start script executable: chmod +x start_node.sh"
echo "3. Launch the node: ./start_node.sh"
